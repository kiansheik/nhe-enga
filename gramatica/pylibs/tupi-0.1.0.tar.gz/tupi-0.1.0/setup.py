from setuptools import setup, find_packages

setup(
    name='tupi',
    version='0.1.0',
    packages=find_packages(),
    description='Description of your package',
    author='Kian Sheik',
    author_email='kiansheik3128@gmail.com',
    url='https://github.com/kiansheik/nhe-enga',
    # Add any other relevant metadata or dependencies
)
