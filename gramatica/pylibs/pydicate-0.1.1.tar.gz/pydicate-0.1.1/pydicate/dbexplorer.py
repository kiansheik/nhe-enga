# # Make a sqlite3 db locally to store the tupi_only data and keep track of what still needs to be translated
# with sqlite3.connect(DB_PATH) as conn:
#     c = conn.cursor()
#     c.execute(
#         """
#     CREATE TABLE IF NOT EXISTS tupi_only (
#         id INTEGER PRIMARY KEY,
#         vid INTEGER,
#         first_word TEXT,
#         definition TEXT,
#         gloss_language TEXT,
#         gloss TEXT,
#         human_verified INTEGER DEFAULT 0
#     )
#     """
#     )
#     c.execute("CREATE INDEX IF NOT EXISTS idx_vid ON tupi_only(vid)")
#     c.execute("CREATE INDEX IF NOT EXISTS idx_first_word ON tupi_only(first_word)")
#     c.execute(
#         "CREATE INDEX IF NOT EXISTS idx_gloss_language ON tupi_only(gloss_language)"
#     )
#     c.execute("CREATE INDEX IF NOT EXISTS idx_gloss ON tupi_only(gloss)")
#     c.execute(
#         "CREATE INDEX IF NOT EXISTS idx_human_verified ON tupi_only(human_verified)"
#     )
# The following file will be an interface to interact with the tupi_only database.
import os
import sqlite3
from contextlib import closing

DB_PATH = os.path.join(os.path.dirname(__file__), "tupi_only.db")


class NavarroDB:
    def __init__(self, db_path=DB_PATH):
        """Initialize the NavarroDB object."""
        self.db_path = db_path
        self.conn = None
        self.cursor = None
        self._search_cache = {}

    def create_table(self):
        with closing(sqlite3.connect(self.db_path)) as conn:
            cursor = conn.cursor()
            """Create the tupi_only table if it doesn't exist."""
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS tupi_only (
                    id INTEGER PRIMARY KEY,
                    vid INTEGER,
                    first_word TEXT,
                    definition TEXT,
                    gloss_language TEXT,
                    gloss TEXT,
                    human_verified INTEGER DEFAULT 0
                )
                """
            )
            conn.commit()

    # search for word in the tupi_only table
    def search_word(self, word, classname=None):
        cache_key = (word, classname)
        if cache_key in self._search_cache:
            return list(self._search_cache[cache_key])
        def_search = ""
        if classname:
            if classname == "noun":
                def_search = "(s.)"
            elif classname == "postposition":
                def_search = "(posp.)"
            elif classname == "adverb":
                def_search = ["(adv.)", "(conj.)"]
            elif "pronoun" in classname:
                def_search = "pron."
            elif classname == "verb":
                def_search = "(v."
        with closing(sqlite3.connect(self.db_path)) as conn:
            cursor = conn.cursor()
            query = (
                """
            SELECT
              vid,
              first_word,
              definition,
              gloss_language,
              GROUP_CONCAT(gloss, ', ') AS glosses
            FROM
              tupi_only
            WHERE
              first_word = ?
            """
                + (
                    (
                        "AND ("
                        + (
                            " OR ".join([f" definition LIKE ? " for _ in def_search])
                            if type(def_search) is list
                            else f" definition LIKE ?"
                        )
                        + ")"
                    )
                    if def_search
                    else ""
                )
                + """ GROUP BY
              vid, first_word, definition, gloss_language
            """
            )
            params = [word] + (
                (
                    [f"%{x}%" for x in def_search]
                    if type(def_search) is list
                    else [f"%{def_search}%"]
                )
                if def_search
                else []
            )
            try:
                # print(f"Executing query: {query} with params: {params}")
                cursor.execute(query, params)
                results = cursor.fetchall()
            except sqlite3.Error as e:
                print(f"Error executing query: \n{query}\n with params \n{params}\n")
                print(f"Error fetching data: {e}")
                breakpoint()

            vids = set(row[0] for row in results)
            # reduce vid languages into single TupiVerbete objects and return a list of them
            tupi_verbetes = []
            for vid in vids:
                first_word = None
                definition = None
                english_glosses = ""
                portuguese_glosses = ""
                for row in results:
                    if row[0] == vid:
                        if not first_word:
                            first_word = row[1]
                        if not definition:
                            definition = row[2]
                        if row[3].strip() == "en":
                            english_glosses = row[4]
                        elif row[3].strip() == "pt":
                            portuguese_glosses = row[4]
                tupi_verbetes.append(
                    TupiVerbete(
                        first_word,
                        definition=definition,
                        english_glosses=english_glosses,
                        portuguese_glosses=portuguese_glosses,
                    )
                )
            result = tupi_verbetes if tupi_verbetes else []
            self._search_cache[cache_key] = tuple(result)
            return list(result)

    def iter_words_by_classname(self, classname=None):
        """
        Iterate over all words in the tupi_only table filtered by the given class.
        Yields TupiVerbete objects.
        """
        def_search = ""
        if classname:
            if classname == "noun":
                def_search = "(s.)"
            elif classname == "postposition":
                def_search = "(posp.)"
            elif classname == "adverb":
                def_search = ["(adv.)", "(conj.)"]
            elif "pronoun" in classname:
                def_search = "pron."
            elif classname == "verb":
                def_search = "(v."
        with closing(sqlite3.connect(self.db_path)) as conn:
            cursor = conn.cursor()
            query = (
                """
            SELECT
              vid,
              first_word,
              definition,
              gloss_language,
              GROUP_CONCAT(gloss, ', ') AS glosses
            FROM
              tupi_only
            """
                + (
                    (
                        "WHERE ("
                        + (
                            " OR ".join([f" definition LIKE ? " for _ in def_search])
                            if type(def_search) is list
                            else " definition LIKE ?"
                        )
                        + ")"
                    )
                    if def_search
                    else ""
                )
                + """ GROUP BY
              vid, first_word, definition, gloss_language
            ORDER BY
              first_word, vid
            """
            )
            params = (
                [f"%{x}%" for x in def_search]
                if type(def_search) is list
                else ([f"%{def_search}%"] if def_search else [])
            )
            try:
                cursor.execute(query, params)
                results = cursor.fetchall()
            except sqlite3.Error as e:
                print(f"Error executing query: \n{query}\n with params \n{params}\n")
                print(f"Error fetching data: {e}")
                breakpoint()

            if not results:
                return

            vid_order = []
            by_vid = {}
            for row in results:
                vid = row[0]
                if vid not in by_vid:
                    by_vid[vid] = {
                        "first_word": row[1],
                        "definition": row[2],
                        "english_glosses": "",
                        "portuguese_glosses": "",
                    }
                    vid_order.append(vid)
                if row[3].strip() == "en":
                    by_vid[vid]["english_glosses"] = row[4]
                elif row[3].strip() == "pt":
                    by_vid[vid]["portuguese_glosses"] = row[4]

            for vid in vid_order:
                data = by_vid[vid]
                yield TupiVerbete(
                    data["first_word"],
                    definition=data["definition"],
                    english_glosses=data["english_glosses"],
                    portuguese_glosses=data["portuguese_glosses"],
                )

    def filter_words_by_definition(self, definition):
        """Filter words in the tupi_only table by definition."""
        with closing(sqlite3.connect(self.db_path)) as conn:
            cursor = conn.cursor()
            query = """
            SELECT
              vid,
              first_word,
              definition,
              gloss_language,
              GROUP_CONCAT(gloss, ', ') AS glosses
            FROM
              tupi_only
            WHERE
              definition LIKE ?
            GROUP BY
              vid, first_word, definition, gloss_language
            """
            params = [f"%{definition}%"]
            cursor.execute(query, params)
            results = cursor.fetchall()
            # Fit the results into TupiVerbete objects, consolodating the languages
            vids = set(row[0] for row in results)
            tupi_verbetes = dict()
            for row in results:
                vid = row[0]
                if vid not in tupi_verbetes:
                    tupi_verbetes[vid] = TupiVerbete(
                        row[1],
                        definition=row[2],
                        english_glosses="",
                        portuguese_glosses="",
                    )
                if row[3].strip() == "en":
                    tupi_verbetes[vid].english_glosses_string += (
                        ", " + row[4]
                        if tupi_verbetes[vid].english_glosses_string
                        else row[4]
                    )
                    # recalculate the english glosses list
                    tupi_verbetes[vid].english_glosses = [
                        x.strip()
                        for x in tupi_verbetes[vid].english_glosses_string.split(",")
                    ]
                elif row[3].strip() == "pt":
                    tupi_verbetes[vid].portuguese_glosses_string += (
                        ", " + row[4]
                        if tupi_verbetes[vid].portuguese_glosses_string
                        else row[4]
                    )
                    # recalculate the portuguese glosses list
                    tupi_verbetes[vid].portuguese_glosses = [
                        x.strip()
                        for x in tupi_verbetes[vid].portuguese_glosses_string.split(",")
                    ]
            return list(tupi_verbetes.values()) if tupi_verbetes else []


class TupiVerbete:
    def __init__(
        self, verbete, definition="", english_glosses="", portuguese_glosses=""
    ):
        """Initialize a TupiVerbete object."""
        self.verbete = verbete
        self.definition = definition
        self.english_glosses_string = english_glosses
        self.portuguese_glosses_string = portuguese_glosses
        self.english_glosses = [x.strip() for x in english_glosses.split(",")]
        self.portuguese_glosses = [x.strip() for x in portuguese_glosses.split(",")]

    def __repr__(self):
        return f"{self.verbete} - {self.definition} [EN: {self.english_glosses_string}] [PT: {self.portuguese_glosses_string}]"


if __name__ == "__main__":
    import sys

    db = NavarroDB()
    # Example usage
    word = sys.argv[1] if len(sys.argv) > 1 else "ko'yré"
    tupi_verbete = db.search_word(
        word, classname=sys.argv[2] if len(sys.argv) > 2 else None
    )
    if tupi_verbete:
        print(tupi_verbete)
    else:
        print(f"No results found for {word}.")
