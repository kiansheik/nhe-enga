from .noun import *
from .adverb import *
from .postposition import *
from .verb import *
from .copula import *
from .y_fix import *
from .demonstrative import *
from .deverbal import *
from .particle import *
from .interjection import *
from .number import *
from .deadverbal import *

abé = Conjunction("abé", tag="[CONJUNCTION:AND]")  # Tupi for "and"
paben = Conjunction("pab˜e", tag="[CONJUNCTION:ALL]")  # Tupi for "and"
erimbae = Adverb("erimba'e", tag="[ADVERB]")  # Tupi for "also" or "too"
ne = YFix(Adverb("ne", tag="[FUTURE]"))
ymo = YFix(Adverb("mo", tag="[IRREALIS_SUFIX]"))  # Make into a irreal particle
umã = Adverb("umã", tag="[PRETERITE]")
mã = YFix(Adverb("mã", tag="[EXHALTIVE_SUFIX]"))  # Make into a irreal particle
temõ = YFix(Adverb("temõ", tag="[WISHFUL_SUFIX]"))  # Make into a irreal particle


def v(noun):
    pf = noun.noun.pluriforme
    vc = "(adj.)"
    # Nominal M-pluriforms do not project onto verbalized adjective stems.
    if pf and pf != "m":
        vc = f"({pf})" + vc
    return Verb(
        noun.noun.verbete(anotated=True),
        verb_class=vc,
        definition=noun.noun.raw_definition,
    )
