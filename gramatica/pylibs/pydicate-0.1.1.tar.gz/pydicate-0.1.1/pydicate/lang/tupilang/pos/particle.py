from pydicate import Predicate
from pydicate.lang.tupilang.pos.y_fix import YFix


class Particle(Predicate):
    def __init__(self, value, definition="", tag="[PARTICLE]", category="particle"):
        """Initialize a Particle object."""
        super().__init__(
            verbete=value,
            category=category,
            min_args=0,
            max_args=1,
            definition=definition,
        )
        self.tag = tag
        self.clitic = "ADVERSATIVE" in tag if tag else False

    def preval(self, annotated=False):
        """Evaluate the Particle object."""
        if annotated:
            return f"{self.verbete}{self.tag}"
        return self.verbete

    def __add__(self, other):
        return other.__addpre__(self)


é = Particle(
    "é",
    definition="really is, actually is, gives focus to what precedes",
    tag="[PARTICLE:FOCUS]",
)
te = YFix(
    Particle(
        "te",
        definition="however, 'on the other hand...', adversitive discourse marker, shifting focus to what precedes it, 'but this in contrast...",
        tag="[PARTICLE:ADVERSATIVE]",
    )
)


peQ = YFix(
    Particle(
        "pe",
        definition="question marker, marks topic of question",
        tag="[PARTICLE:INTERROGATIVE]",
    )
)
