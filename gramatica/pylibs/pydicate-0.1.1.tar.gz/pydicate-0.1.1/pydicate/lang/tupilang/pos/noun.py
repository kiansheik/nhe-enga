from pydicate import Predicate
from tupi import Noun as TupiNoun
from pydicate.lang.tupilang.pos.copula import *
from tupi import AnnotatedString
from pydicate.lang.tupilang.pos.interjection import *
from pydicate.lang.tupilang.pos.adverb import *
import re


class Noun(Predicate):
    def __init__(
        self,
        value,
        definition="",
        inflection=None,
        pro_drop=False,
        tag="[NOUN]",
        category="noun",
        noroot: bool = False,
    ):
        """Initialize a Noun object."""
        super().__init__(
            verbete=value, category=category, min_args=0, definition=definition, tag=tag
        )
        self.noun = TupiNoun(self.verbete, self.functional_definition, noroot=noroot)
        self._inflection = inflection
        defn_lower = (definition or "").lower()
        # Grammatical markers like "(t)" / "(s)" / "(m)" are expected in
        # the leading parenthetical header, not arbitrary gloss text.
        marker_block_match = re.match(r"^\s*(?:\([^)]*\)\s*)+", defn_lower)
        marker_block = marker_block_match.group(0) if marker_block_match else ""
        if "(m)" in marker_block:
            self.noun.pluriforme = "m"
            self.noun.m_pluriforme = True
        elif "(s)" in marker_block:
            self.noun.pluriforme = "s"
        elif "(t)" in marker_block:
            self.noun.pluriforme = "t"
        if inflection:
            self.plural = "pp" in inflection
        self.pro_drop = pro_drop
        for val, infl in self.noun.personal_inflections.items():
            if self.verbete.lower() == infl[0]:
                self._inflection = val
                break
        self.posto = "posposto"

    def var(self, setter):
        varied = super().var(setter)
        source = getattr(self, "_nominalization_source", None)
        compositions = getattr(source, "compositions", ())
        # Explicit irregular nominal gûatasara ~ atara, requested in Studio.
        # Keep the source/definitions; this is not a general loss of gû-/s.
        # Restrict to the bare sara-derived nominal, not an inflected phrase
        # or a later compound. Treat atar as opaque, without inferred splits.
        if (
            getattr(source, "verbete", None) == "gûatasar"
            and len(compositions) == 1
            and compositions[0].category == "deverbal_noun"
            and compositions[0].verbete == "sara"
            and self.noun.base_verbete in {"gûatasar[ROOT]", "atar[ROOT]"}
            and not self.compositions
        ):
            stem = "atar" if varied.variation_id == 1 else "gûatasar"
            varied.refresh_verbete(stem)
        return varied

    def refresh_verbete(self, new_verbete):
        old = self.copy()
        self.verbete = new_verbete
        self.noun = TupiNoun(self.verbete, self.definition)
        self.noun.m_pluriforme = old.noun.m_pluriforme
        self.noun.pluriforme = old.noun.pluriforme

    def __pos__(self):
        """
        Mark noun as pro_drop the predicate using the + operator.
        :return: Self (to enable chaining).
        """
        neg = self.copy()
        neg.pro_drop = True
        return neg

    def __add__(self, other):
        """
        Add a Noun or Copula to the current Noun.
        :param other: The Noun or Copula to add.
        :return: A new Noun with the added argument.
        """
        if isinstance(other, Interjection) or isinstance(other, Adverb):
            return super().__add__(other)
        if isinstance(other, Conjunction):
            cop = self.copy()
            conj = other.copy()
            # add cop to front of arguments
            conj.arguments.insert(0, cop)
            return conj
        if isinstance(other, (Noun)):
            if self.category in {"deverbal_noun", "deadverbal_noun"} or getattr(
                other, "category", ""
            ) in {"deverbal_noun", "deadverbal_noun"}:
                return super().__add__(other)
            cop = self.copy()
            oth = other.copy()
            conj = Conjunction("", tag="[CONJUNCTION:AND]")
            conj.arguments.append(cop)
            conj.arguments.append(oth)
            return conj
        return super().__add__(other)

    def __addpre__(self, other):
        """
        Add an adjunct using the + operator.
        :param other: The adjunct to add.
        :return: Self (to enable chaining).
        """
        mult = self.copy()
        other_copy = other.copy()
        # prepend the adjunct to the pre_adjuncts
        mult.pre_adjuncts.insert(0, other_copy)
        return mult

    # @grammar[nominal-base] The ordinary branch calls the Tupi noun object's
    # @grammar+ absolute and substantive operations; the negative
    # @grammar+ branch first applies the negative operation. This is
    # @grammar+ the base-form path of this class, not a rule that every
    # @grammar+ historical noun independently bears an overt ending.
    def noun_function(self, neg=False, annotated=False):
        """Return the noun in its base form."""
        if neg:
            return self.noun.eym().absoluta().substantivo(annotated)
        return self.noun.absoluta().substantivo(annotated)

    def preval(self, annotated=False):
        """Evaluate the Noun object."""
        vbt = self.noun_function(neg=self.negated, annotated=annotated)
        tag = ""
        if annotated and self.tag:
            if self.tag == "[NOUN]" and "[NOUN:POSSESSOR]" in vbt:
                tag = ""
            else:
                tag = "" if self.tag in vbt else self.tag
        ret_val = f"{vbt}{tag}"
        for adj in self.pre_adjuncts:
            adj_val = adj.eval(annotated=annotated)
            fuse = False
            if getattr(adj, "category", "") == "pronoun":
                tag_val = getattr(adj, "tag", "") or ""
                if "MAIN_CLAUSE_SUBJECT" in tag_val or (
                    not annotated
                    and any(
                        key in tag_val
                        for key in (
                            "OBJECT",
                            "OBJECT_PREFIX",
                            "OBJECT_MARKER",
                            "PATIENT_PREFIX",
                            "SUBJECT",
                            "SUBJECT_PREFIX",
                        )
                    )
                ):
                    fuse = True
            if fuse:
                ret_val = f"{adj_val}{ret_val}"
            else:
                ret_val = f"{adj_val} {ret_val}"
        ret_val = ret_val.strip()
        for adj in self.post_adjuncts:
            ret_val = f"{ret_val} {adj.eval(annotated=annotated)}"
        return ret_val.strip()

    def __mul__(self, other):
        if isinstance(self, Pronoun) and isinstance(other, Noun):
            tag = getattr(self, "tag", "") or ""
            if "MAIN_CLAUSE_SUBJECT" in tag:
                base = other.copy()
                base.noun.pluriforme = None
                base.noun.m_pluriforme = False
                base.pre_adjuncts.insert(0, self.copy())
                return base
            if "SUBJECT" in tag and "POSSESSIVE_PRONOUN" not in tag:
                base = other.copy()
                adj = self.copy()
                base.pre_adjuncts.insert(0, adj)
                return base
        if isinstance(other, Pronoun):
            tag = getattr(other, "tag", "") or ""
            if any(
                key in tag
                for key in (
                    "OBJECT",
                    "OBJECT_PREFIX",
                    "OBJECT_MARKER",
                    "PATIENT_PREFIX",
                )
            ):
                base = self.copy()
                adj = other.copy()
                base.pre_adjuncts.insert(0, adj)
                return base
            if "SUBJECT" in tag and "POSSESSIVE_PRONOUN" not in tag:
                base = self.copy()
                adj = other.copy()
                base.pre_adjuncts.insert(0, adj)
                return base
        # When its another Noun, we treat it as a possessive construction
        if other.verbete == "emi":
            deverbal = other.copy()
            deverbal.arguments[0].arguments.append(self.copy())
            return deverbal
        if "deverbal" in other.category:
            possessor = self.copy()
            base_noun = Noun(other.eval(True), definition=other.definition)

            base_noun.arguments.append(possessor)
            base_noun.noun = base_noun.noun.possessive(
                possessor.inflection(),
                (
                    None
                    if possessor.category == "pronoun"
                    else possessor.eval(annotated=True)
                ),
                fuse=False,
            )
            base_noun.noun.pluriforme = possessor.noun.pluriforme
            return base_noun
        if isinstance(other, Noun):
            possessor = self.copy()
            base_noun = other.copy()

            base_noun.arguments.append(possessor)
            base_noun.noun = base_noun.noun.possessive(
                possessor.inflection(),
                (
                    None
                    if possessor.category == "pronoun"
                    else possessor.eval(annotated=True)
                ),
                fuse=False,
            )
            # A non-pluriform adjectival nominal acts as a modifier here;
            # it keeps its own null class while the possessor retains its prefix.
            if (
                "adj." in base_noun.noun.raw_definition.lower()
                and base_noun.noun.pluriforme is None
            ):
                return base_noun
            # Possession has already selected the relational form of the
            # possessed root. Suppress its later absolute realization: it
            # would prefix the complete possessor–possessed phrase a second time.
            base_noun.noun.pluriforme = None
            base_noun.noun.m_pluriforme = False
            return base_noun
        # Otherwise, treat itself as the argument to the other predicate
        self_cop = self.copy()
        other_cop = other.copy()
        self_cop.posto = "anteposto"
        return other_cop * self_cop

    def __eq__(self, other):
        # Make sure both are Noun objects
        # if not isinstance(other, self.__class__) or not isinstance(other, Copula):
        #     # raise error that the types being compared are not the same
        #     raise TypeError(f"Cannot compare Noun object with {type(other)} object.")
        return cop() * self * other

    def __matmul__(self, other):
        return self.__eq__(other)

    def inflection(self, setter=None):
        if setter:
            self._inflection = setter
        return self._inflection if self._inflection else "3p"

    def __repr__(self):
        return self.eval(annotated=False)

    def voc(self):
        """Return the noun in its vocative form."""
        return VocativeNoun(self)

    # define VocativeNoun subclass of Noun which implements Interjetion type behavior
    def __truediv__(self, modifier):
        # A noun incorporated into a transitive verb changes the verb's
        # valency. Other noun compositions retain Predicate.compose's rules.
        from pydicate.lang.tupilang.pos.verb import Verb, IncorporatedObjectVerb

        if isinstance(modifier, Verb) and modifier.verb.transitivo:
            return IncorporatedObjectVerb(self, modifier)
        return super().__truediv__(modifier)


class VocativeNoun(Noun, Interjection):
    # the class simply takes a Noun object and returns a deep copy of the noun, plus voctative flag as it currently implements
    def __init__(self, noun: Noun):
        voc_copy = noun.copy()
        voc_copy.noun = (
            voc_copy.noun.vocativo()
            if voc_copy.category != "proper_noun"
            else voc_copy.noun
        )
        # alter voc_copy to be of new class type
        voc_copy.__class__ = VocativeNoun
        # set all of self's attributes to voc_copy's attributes
        self.__dict__.update(voc_copy.__dict__)
        self.tag = "[VOCATIVE]"

    def __add__(self, other):
        return other.__addpre__(self)


class Conjunction(Noun):
    def __init__(
        self, value, definition="", tag="[CONJUNCTION]", category="conjunction"
    ):
        """Initialize a Conjunction object."""
        super().__init__(
            value,
            inflection="3p",
            pro_drop=False,
            definition=definition,
            tag=tag,
            category=category,
        )
        self.min_args = 2
        self.tag = tag
        self.max_args = None

    def preval(self, annotated=False):
        """Evaluate the Conjunction object."""
        lexeme = self.verbete
        if self.verbete == "abé":
            var_id = 0 if self.variation_id is None else self.variation_id
            if var_id == 1:
                lexeme = "bé"
            if var_id == 2:
                lexeme = "pabẽ"
        suppress_lexeme = bool(getattr(self, "_suppress_lexeme", False))
        if lexeme and not suppress_lexeme:
            suffix = f" {lexeme}{self.tag}"
        elif lexeme and suppress_lexeme:
            suffix = ""
        else:
            # A zero-surface coordinator scopes over the construction. Appending
            # its tags here would falsely attach AND to the last child's suffix.
            # The node and its tag remain in the structured annotation audit.
            suffix = ""
        argument_values = [x.eval(annotated=annotated) for x in self.arguments]
        # memẽ is attested between its two coordinated members; other lexical
        # conjunctions (notably abé/bé) remain postposed.
        if lexeme == "memẽ" and len(argument_values) >= 2:
            nec = (
                " ".join(argument_values[:-1])
                + f" {lexeme}{self.tag} {argument_values[-1]}"
            )
        else:
            nec = " ".join(argument_values) + suffix
        if self.post_adjuncts:
            # TODO: When evaling adjunct, check if yfix for space or y
            nec += " " + " ".join(
                [x.eval(annotated=annotated).strip() for x in self.post_adjuncts]
            )
        if self.pre_adjuncts:
            nec = (
                " ".join([x.eval(annotated=annotated) for x in self.pre_adjuncts])
                + " "
                + nec.strip()
            )
        return AnnotatedString(nec).verbete(annotated=annotated).strip()

    def inflection(self):
        retval = "3p"
        arg_inflections = [x.inflection() for x in self.arguments]
        arg_inflections = [x for x in arg_inflections if x]
        # if "1p" or "2p" are present in any strings in arg_inflections, then return true
        if any("1p" in x for x in arg_inflections) and any(
            "2p" in x for x in arg_inflections
        ):
            retval = "1ppi"
        elif any("1p" in x for x in arg_inflections):
            retval = "1ppe"
        elif any("2p" in x for x in arg_inflections):
            retval = "2pp"
        return retval

    def __add__(self, other):
        if isinstance(other, Noun):
            cop = self.copy()
            cop.arguments.append(other.copy())
            return cop
        else:
            return super().__add__(other)

    def __mul__(self, other):
        # Once explicitly nominalized, a coordinated phrase can be the
        # possessor of a following noun.  Without this marker, lexical
        # conjunctions retain their ordinary argument-adding behavior.
        if getattr(self, "_nominalized_conjunction", False) and isinstance(other, Noun):
            return Noun.__mul__(self, other)
        # A null conjunction can scope over a lexical coordinator without
        # introducing its exponent: preserve the coordinated arguments, but
        # render the coordinator as null and retain the null-conjunction tag.
        if not self.verbete.strip() and isinstance(other, Conjunction):
            cop = other.copy()
            cop._suppress_lexeme = True
            cop.tag = self.tag
            return cop
        # Lexical conjunctions used with `*` coordinate phrases as a noun-like
        # container, while still rendering the conjunction surface at the end.
        if self.verbete:
            cop = self.copy()
            if other.category == "verb":
                cop.posto = "anteposto"
                return other * cop
            if isinstance(other, Predicate):
                cop.arguments.append(other.copy())
                # Treat as a noun phrase for downstream verbal-object handling.
                cop.category = "classifier_noun"
                return cop
        return super().__mul__(other)

    def base_nominal(self, annotated=False):
        nominal = self.copy()
        # Preserve the coordinator's ordinary behavior until this explicit
        # nominalization is requested by the expression.
        nominal._nominalized_conjunction = True
        return nominal


class ProperNoun(Noun):
    def __init__(
        self, value, tag="[PROPER_NOUN]", category="proper_noun", definition=""
    ):
        super().__init__(
            value=value,
            inflection="3p",
            definition=value,
            pro_drop=False,
            tag=tag,
            category=category,
        )

    def noun_function(self, neg=False, annotated=False):
        """Return the noun in its base form."""
        if neg:
            return self.noun.eym().substantivo(annotated)
        return AnnotatedString(f"{self.verbete}{self.tag}").verbete(annotated)


class Pronoun(Noun):
    def __init__(
        self,
        inflection_or_verbete,
        pro_drop=False,
        definition="",
        tag="[PRONOUN]",
        category="pronoun",
        inflection_override=None,
    ):
        """Initialize a Pronoun object."""
        if inflection_or_verbete in TupiNoun.personal_inflections.keys():
            pronoun = TupiNoun.personal_inflections[inflection_or_verbete][0]
            inflection = inflection_or_verbete
        else:
            pronoun = inflection_or_verbete
            inflection = "3p"
        super().__init__(
            value=pronoun,
            inflection=inflection,
            pro_drop=pro_drop,
            definition=definition,
            tag=tag,
            category=category,
        )
        self.category = "pronoun"
        if inflection_override:
            self._inflection = inflection_override
        # add the inflection to the end of the tag with : before the end bracket appended onto the rest if it's not already there
        if tag and self.inflection() not in tag:
            self.tag = tag[:-1] + f":{self.inflection()}" + tag[-1:]

    def noun_function(self, neg=False, annotated=False):
        """Return the noun in its base form."""
        if neg:
            return AnnotatedString(self.noun.eym().verbete()).verbete(annotated)
        variant = {"refl": "nhe", "mut": "nho", "gen": "mor"}.get(self.inflection())
        surface = variant if self.variation_id == 1 and variant else self.noun.verbete()
        return AnnotatedString(surface).verbete(annotated)

    def inflection(self, setter=None):
        if setter:
            self._inflection = setter
        if (
            self.verbete == "moro"
            and self._inflection == "gen"
            and self.variation_id == 1
        ):
            return "gen_compound"
        return super().inflection()


ixé = Pronoun("1ps", definition="I")
xe = Pronoun("1ps", definition="I")
îandé = Pronoun("1ppi", definition="we (inclusive)")
oré = Pronoun("1ppe", definition="we (exclusive)")
endé = Pronoun("2ps", definition="you")
nde = Pronoun("2ps", definition="you")
pee = Pronoun("2pp", definition="y'all'")
ae = Pronoun("3p", definition="he/she/it/they")

# Role-specific pronouns for explicit subject/object tagging.
ixé_suj = Pronoun("1ps", definition="I", tag="[SUBJECT:1ps]")
ixé_obj = Pronoun("1ps", definition="I", tag="[OBJECT:1ps]")
xe_suj = Pronoun("1ps", definition="I", tag="[SUBJECT:1ps]")
xe_obj = Pronoun("1ps", definition="I", tag="[OBJECT:1ps]")
îandé_suj = Pronoun("1ppi", definition="we (inclusive)", tag="[SUBJECT:1ppi]")
îandé_obj = Pronoun("1ppi", definition="we (inclusive)", tag="[OBJECT:1ppi]")
oré_suj = Pronoun("1ppe", definition="we (exclusive)", tag="[SUBJECT:1ppe]")
oré_obj = Pronoun("1ppe", definition="we (exclusive)", tag="[OBJECT:1ppe]")
endé_suj = Pronoun("2ps", definition="you", tag="[SUBJECT:2ps]")
endé_obj = Pronoun("2ps", definition="you", tag="[OBJECT:2ps]")
nde_suj = Pronoun("2ps", definition="you", tag="[SUBJECT:2ps]")
nde_obj = Pronoun("2ps", definition="you", tag="[OBJECT:2ps]")
pee_suj = Pronoun("2pp", definition="y'all'", tag="[SUBJECT:2pp]")
pee_obj = Pronoun("2pp", definition="y'all'", tag="[OBJECT:2pp]")
ae_suj = Pronoun("3p", definition="he/she/it/they", tag="[SUBJECT:3p]")
ae_obj = Pronoun("3p", definition="he/she/it/they", tag="[OBJECT:3p]")
moro = Pronoun(
    "gen", definition="generic, people", tag="[PRONOUN:GENERIC:PEOPLE_IN_GENERAL]"
)
moro.noun = TupiNoun("moro", moro.functional_definition, noroot=True)
îe = Pronoun(
    "refl", definition="to oneself, one's own", tag="[OBJECT_PREFIX:REFLEXIVE]"
)
îo = Pronoun("mut", definition="to one another", tag="[OBJECT_PREFIX:RECIPROCAL]")
nhe = îe.var(1)
nho = îo.var(1)
og = Pronoun(
    "o",
    definition="refers to the subject of the main clause",
    tag="[PRONOUN:MAIN_CLAUSE_SUBJECT]",
)
og._inflection = "suj"

# Prefix-style subject pronoun (used for explicit subject-prefix markers).
o_prefix = Pronoun("o", definition="3p subject prefix", tag="[SUBJECT_PREFIX:3p]")

asé = Noun(
    "asé", definition="We, people in general, all of us", tag="[PRONOUN:UNIVERSAL_WE]"
)

pronoun_verbetes = [x.verbete for x in [ixé, îandé, oré, endé, pee, ae]]
