# pydicate: A library for generalized linguistic predicates

from .predicate import Predicate
