from pydicate.lang.tupilang import *
