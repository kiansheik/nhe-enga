from pydicate.lang.tupilang.nouns import *
