# __init__.py

from .tupi import TupiAntigo
from .verb import Verb  # Replace with actual class or function names
from .noun import Noun  # Replace with actual class or function names