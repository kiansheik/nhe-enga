import unicodedata

nasal_prefix_map = {
    "p": "mb",
    "k": "ng",
    "t": "nd",
    "s": "nd",
}

accent_map = {
    "á": "a",
    "é": "e",
    "í": "i",
    "ý": "y",
    "ó": "o",
    "ú": "u",
}

nasal_map = {
    "á": "ã",
    "é": "ẽ",
    "í": "ĩ",
    "ý": "ỹ",
    "ó": "õ",
    "ú": "ũ",
    "a": "ã",
    "e": "ẽ",
    "i": "ĩ",
    "y": "ỹ",
    "o": "õ",
    "u": "ũ",
}


class AnnotatedString:
    def __init__(self, annotated: str):
        self.original = annotated
        self._rebuild_maps()

    def _rebuild_maps(self):
        self.clean = ""
        self.map_clean_to_annotated = []
        i = 0
        while i < len(self.original):
            if self.original[i] == "[":
                while i < len(self.original) and self.original[i] != "]":
                    i += 1
                i += 1  # skip the closing ']'
            else:
                self.map_clean_to_annotated.append(i)
                self.clean += self.original[i]
                i += 1

    def __getitem__(self, key):
        if isinstance(key, int):
            if key < 0:
                key += len(self.clean)
            if key < 0 or key >= len(self.clean):
                raise IndexError("Index out of range")
            i = self.map_clean_to_annotated[key]
            return self.original[i]
        elif isinstance(key, slice):
            indices = self.map_clean_to_annotated[key]
            if not indices:
                return ""
            start = indices[0]
            end = indices[-1] + 1
            return self.original[start:end]
        else:
            raise TypeError("Invalid argument type")

    def __str__(self):
        return self.original

    def __repr__(self):
        return f"AnnotatedString({self.original!r})"

    def __len__(self):
        return len(self.clean)

    def get_clean(self):
        return self.clean

    def get_annotated(self):
        return self.original

    def verbete(self, annotated=False):
        """Return the verbete of the annotated string."""
        if annotated:
            return self.original
        return self.clean

    def endswith(self, suffix):
        return self.clean.endswith(suffix)

    def startswith(self, prefix):
        return self.clean.startswith(prefix)

    def replace(self, old, new):
        start = self.clean.find(old)
        if start == -1:
            return False
        end = start + len(old)
        i1 = self.map_clean_to_annotated[start]
        i2 = self.map_clean_to_annotated[end - 1] + 1
        self.original = self.original[:i1] + new + self.original[i2:]
        self._rebuild_maps()
        return True

    def insert_prefix(self, prefix):
        self.original = prefix + self.original
        self._rebuild_maps()
        return self

    def insert_suffix(self, suffix):
        self.original += suffix
        self._rebuild_maps()
        return self

    def replace_clean(
        self,
        start: int,
        length: int = 1,
        replacement: str = "",
        drop_trailing_tag=False,
    ):
        clean_len = len(self.clean)

        # Normalize negative start
        if start < 0:
            start += clean_len
        if not (0 <= start <= clean_len):
            raise IndexError(f"Invalid start index: {start}")

        # Normalize length
        if length is None:
            end = clean_len
        else:
            end = start + length
            if not (0 <= end <= clean_len):
                raise IndexError(f"Invalid length: {length}")

        # Map to annotated string indices
        annotated_start = (
            self.map_clean_to_annotated[start]
            if start < clean_len
            else len(self.original)
        )
        annotated_end = self.map_clean_to_annotated[end - 1] + 1

        # Replace in original
        self.original = (
            self.original[:annotated_start]
            + replacement
            + self.original[annotated_end:]
        )
        self._rebuild_maps()

        # Drop trailing tag if requested and present
        if drop_trailing_tag and self.original and self.original[-1] == "]":
            last_open = self.original.rfind("[")
            last_close = self.original.rfind("]")
            if (
                last_open != -1
                and last_close == len(self.original) - 1
                and last_open < last_close
            ):
                self.original = self.original[:last_open]
                self._rebuild_maps()

    def remove_accent_last_vowel(self):
        vowels = "áéíýóú"
        # Check if the last character is an accented vowel
        if self[-1] in vowels:
            # Remove the accent from the last vowel
            self.replace_clean(-1, 1, accent_map[self[-1]])
        return self

    def accent_last_vowel(self):
        vowels = "aeiyou"
        # Check if the last character is a vowel
        if self[-1] in vowels:
            # Accent the last vowel
            accented = self[-1] + "́"
            normalized = unicodedata.normalize("NFC", accented)
            self.replace_clean(-1, 1, normalized)
        return self

    def nasaliza_final(self):
        # Check if the last character is an accented vowel
        if self[-1] in nasal_map.keys():
            # Remove the accent from the last vowel
            self.replace_clean(-1, 1, nasal_map[self[-1]])
        return self

    def nasaliza_prefixo(self):
        if self[0] in nasal_prefix_map.keys():
            return self.replace_clean(0, 1, nasal_prefix_map[self[0]])
        return self

    def remove_ending_if_any(self, endings):
        for ending in endings:
            if self.endswith(ending):
                self.replace_clean(-len(ending), len(ending), "")
                # exit the loop after the first match
                return self
        return self

    def strip(self, to_strip=" "):
        """Strip whitespace from the annotated string."""
        self.original = self.original.strip(to_strip)
        self._rebuild_maps()
        return self

    def strip_original(self, to_strip=" "):
        """Strip whitespace from the original string."""
        self.original = self.original.strip(to_strip)
        self._rebuild_maps()
        return self

    def removesuffix_original(self, suffix):
        """Remove the suffix from the annotated string."""
        if self.original.endswith(suffix):
            self.original = self.original[: -len(suffix)]
            self._rebuild_maps()
        return self

    def drop_last_tag(self):
        """Drop the last tag from the annotated string."""
        if "[" in self.original:
            last_open = self.original.rfind("[")
            last_close = self.original.rfind("]")
            if last_open != -1 and last_close != -1 and last_open < last_close:
                self.original = (
                    self.original[:last_open] + self.original[last_close + 1 :]
                )
                self._rebuild_maps()
        return self.strip()

    def drop_all_last_tags(self):
        """Drop all tags from the end of the annotated string."""
        while "[" in self.original and self.original.endswith("]"):
            last_open = self.original.rfind("[")
            last_close = self.original.rfind("]")
            if last_open != -1 and last_close != -1 and last_open < last_close:
                self.original = (
                    self.original[:last_open] + self.original[last_close + 1 :]
                )
                self._rebuild_maps()
        return self.strip()

    def drop_until_last_tag(self):
        """
        From the last real character, drop any tags that follow it in sequence,
        but preserve the first tag immediately after the character (if any).
        """
        if not self.clean or not self.map_clean_to_annotated:
            return self.strip()

        # Get the index in self.original of the last real character
        last_char_idx = self.map_clean_to_annotated[-1]

        # Scan forward from last_char_idx+1 to find tags
        i = last_char_idx + 1
        kept_tag = False
        new_original = self.original[:i]

        while i < len(self.original):
            if self.original[i] == "[":
                tag_start = i
                tag_end = self.original.find("]", tag_start)
                if tag_end == -1:
                    break  # malformed tag, stop

                if not kept_tag:
                    # keep the first tag
                    new_original += self.original[tag_start : tag_end + 1]
                    kept_tag = True
                # skip the rest (i.e., drop tag)
                i = tag_end + 1
            else:
                # stray character after the last real one — usually shouldn't happen
                break

        self.original = new_original
        self._rebuild_maps()
        return self.strip()

    def __add__(self, other):
        """Concatenate two AnnotatedString objects."""
        if isinstance(other, AnnotatedString):
            new_string = self.original + other.original
            return AnnotatedString(new_string)
        elif isinstance(other, str):
            return self.insert_suffix(other)
        else:
            raise TypeError(
                "Can only concatenate AnnotatedString or str to AnnotatedString"
            )
